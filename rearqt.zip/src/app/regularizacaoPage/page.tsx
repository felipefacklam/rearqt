export default function RegularizacaoPage() {
    return (
        <div>
            <h1>
                Projetos de Regularizacao
            </h1>
        </div>
    );
}