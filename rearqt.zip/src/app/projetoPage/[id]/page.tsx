import Footer from "@/components/Footer";
import Header from "@/components/Header";
import Projeto from "@/components/Projeto";


export default function ProjetoPage() {
  

  return (
    <div>
      <Header />
      <Projeto />
      <Footer />
    </div>
  );
}
